exports.handler = function (event, context, callback) {
   var response = {
      statusCode: 200,
      headers: {
         "Access-Control-Allow-Headers" : "Content-Type",
         "Access-Control-Allow-Origin": "http://bbad86bf-e69b-49ba-b02f-54911cb672ab-frontend.s3-website-us-west-2.amazonaws.com",
         "Access-Control-Allow-Methods": "GET,POST"
      },
      body: '<p>Hello, world!</p>' //+ JSON.stringify(context) + "<p>" + JSON.stringify(event)
   }
   if (event.body) { response.body = "<p>Hello, " + event.body + "!</p>"; }
   callback(null, response);
}
